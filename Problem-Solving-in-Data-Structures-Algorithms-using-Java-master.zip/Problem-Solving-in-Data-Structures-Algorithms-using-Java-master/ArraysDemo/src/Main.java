
public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayDemo d = new ArrayDemo();
		d.addValue(0, 1);
		d.addValue(1, 2);
		System.out.println(d.getValue(0));
		System.out.println(d.getValue(1));

	}

}
