public class LinkedList {

	private static class Node {
		private int value;
		private Node next;
		// Nested Class Node other fields and methods.

	}

	private Node head;
	private int size = 0;
	// Outer Class LinkedList other fields and methods.
}