public class OuterClass {

	class NestedClass {
		// NestedClass fields and methods.
	}

	// OuterClass fields and methods.
}