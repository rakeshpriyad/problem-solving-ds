import java.util.TreeSet;

public class TreeSetDemo {
	public static void main(String[] args) {
		// Create a tree set.
		TreeSet<String> ts = new TreeSet<String>();
		// Add elements to the tree set.
		ts.add("India");
		ts.add("USA");
		ts.add("Brazile");
		ts.add("Canada");
		ts.add("UK");
		ts.add("China");
		ts.add("France");
		ts.add("Spain");
		ts.add("Italy");
		System.out.println(ts);
	}
}