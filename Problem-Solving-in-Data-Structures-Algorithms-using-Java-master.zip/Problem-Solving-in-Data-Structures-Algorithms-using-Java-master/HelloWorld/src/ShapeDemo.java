
public class ShapeDemo {

	public ShapeDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {

	}

}
