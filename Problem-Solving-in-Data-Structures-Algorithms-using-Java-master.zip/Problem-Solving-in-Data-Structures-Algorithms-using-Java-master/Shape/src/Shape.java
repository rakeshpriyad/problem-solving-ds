//Abstract Class
public abstract class Shape {
	// Abstract Method
	public abstract double area();

	// Abstract Method
	public abstract double perimeter();
}